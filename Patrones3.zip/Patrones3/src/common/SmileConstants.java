package common;

public interface SmileConstants {

  public static final int SMILE_UP = 0;
  public static final int SMILE_DW = 1;
  public static final int SMILE_OK = 3;
}
